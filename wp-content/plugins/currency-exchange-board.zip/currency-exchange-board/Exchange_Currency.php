<?php
/*
Plugin Name: Currency bank Exchange Board
Description: Display currency bank exchange rates.
Version: 1.0
Author: Nadeen
*/

// Add a menu item to the admin menu
function currency_bank_exchange_settings_menu() {
    add_menu_page(
        'Currency bank Exchange Settings',
        'Currency bank Exchange',
        'manage_options',
        'currency-bank-exchange-settings',
        'currency_bank_exchange_settings_page'
    );
}
add_action('admin_menu', 'currency_bank_exchange_settings_menu');

// Display the settings page
function currency_bank_exchange_settings_page() {
    ?>
    <div class="wrap">
        <h2>Currency bank Exchange Settings</h2>
        <form method="post" multiple action="options.php">
            <?php settings_fields('currency_bank_exchange_settings_group'); ?>
            <?php do_settings_sections('currency-bank-exchange-settings'); ?>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Register settings and fields
function currency_bank_exchange_register_settings() {
    register_setting('currency_bank_exchange_settings_group', 'currency_exchange_SVG');
    $currencies = array(
        'USD', 'SAR', 'EUR', 'AED', 'KWD', 'GBP', 'OMR', 'CNY', 'QAR', 'CAD', 'JOD', 'AUD', 'BHD', 'CHF', 'JPY', 'SEK', 'DKK', 'NOK'
    );

    foreach ($currencies as $currency) {
        add_settings_section(
            'currency_bank_section_' . $currency,
            $currency . ' Settings',
            'currency_bank_section_callback',
            'currency-bank-exchange-settings'
        );

        add_settings_field(
            'currency_SVGS_' . $currency,
            'SVGS for ' . $currency,
            'currency_SVGS_callback',
            'currency-bank-exchange-settings',
            'currency_bank_section_' . $currency,
            array('currency' => $currency)
        );

    }
}
add_action('admin_init', 'currency_bank_exchange_register_settings');

// Callback for each currency section
function currency_bank_section_callback() {
    // This function intentionally left blank
}

// Callback for currency SVGS field
function currency_SVGS_callback($args) {
    $currency = $args['currency'];
    $currency_exchange_SVG = get_option('currency_exchange_SVG');

    if (isset($currency_exchange_SVG[$currency])) {
        $currency_SVGS = esc_url($currency_exchange_SVG[$currency]);
    } else {
        $currency_SVGS = '';
    }

    echo "<input type='file' access='image/SVG' name='currency_exchange_SVG[$currency]' value='$currency_SVGS' style='width: 100%;'>";
}


// Shortcode to display currency exchange board
function display_currency_bank_exchange_board() {
    $currencies = array(
        'USD', 'SAR', 'EUR', 'AED', 'KWD', 'GBP', 'OMR', 'CNY', 'QAR', 'CAD', 'JOD', 'AUD', 'BHD', 'CHF', 'JPY', 'SEK', 'DKK', 'NOK'
    );

    $exchange_rates = get_currency_exchange_rates();

    echo '<div class="currency-board">';
    echo '<table style="border-collapse: collapse; width: 100%;">';
    echo '<tbody>';

    foreach ($currencies as $currency) {
        $reciprocal_rate = isset($exchange_rates[$currency]) ? number_format(1 / $exchange_rates[$currency], 2) : 0;
        $currency_exchange_SVG = get_option('currency_exchange_SVG');
        $currency_SVGS = isset($currency_exchange_SVG[$currency]) ? esc_url($currency_exchange_SVG[$currency]) : '';
       

        echo '<tr >';
        echo "<td ><img src='$currency_SVGS'/></td>";
        echo "<td style='text-align: left; padding: 10px 0;'>{$currency}/EGP</td>";
        echo "<td style='text-align: right; padding: 10px;'>{$reciprocal_rate}</td>";
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
    echo '</div>';
}
add_shortcode('currency_bank_exchange_board', 'display_currency_bank_exchange_board');

// Function to fetch currency exchange rates
function get_currency_exchange_rates() {
    $api_key = 'a830998e5453e63e5bdbe4af';
    $base_currency = 'EGP';

    $api_url = "https://open.er-api.com/v6/latest/{$base_currency}?apikey={$api_key}";
    $response = wp_remote_get($api_url);

    if (is_wp_error($response)) {
        return array();
    }

    $data = wp_remote_retrieve_body($response);
    $exchange_rates = json_decode($data, true);

    if (!$exchange_rates || !isset($exchange_rates['rates'])) {
        return array();
    }

    return $exchange_rates['rates'];
}

